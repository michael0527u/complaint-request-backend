import openai
from app.core.config import settings

async def chat_with_ai(message: str):
    openai.api_key = settings.OPENROUTER_API_KEY
    response = openai.ChatCompletion.create(
        model="claude-3.5-haiku",
        messages=[{"role": "user", "content": message}]
    )
    return response["choices"][0]["message"]["content"]
