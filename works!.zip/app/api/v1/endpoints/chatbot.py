from fastapi import APIRouter
from app.services.ai_service import generate_letter
from app.core.database import complaints_collection
from datetime import datetime

router = APIRouter()

@router.post("/generate-letter")
async def generate_formal_letter(request: dict):
    letter = await generate_letter(request["description"])

    doc = {
        "user_name": request["user_name"],
        "register_number": request["register_number"],
        "subject": request["subject"],
        "description": request["description"],
        "letter": letter,
        "created_at": datetime.utcnow()
    }
    await complaints_collection.insert_one(doc)

    return {"letter": letter, "message": "Letter generated successfully"}
